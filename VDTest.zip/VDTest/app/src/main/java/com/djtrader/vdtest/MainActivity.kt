package com.djtrader.vdtest

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import rikka.shizuku.Shizuku
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var preview: ImageView
    private lateinit var etW: EditText
    private lateinit var etH: EditText
    private lateinit var etDpi: EditText
    private lateinit var etPkg: EditText

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, res ->
        ui.post { log("Shizuku permission result: ${if (res == 0) "GRANTED" else "DENIED"}"); refreshStatus() }
    }
    private val binderListener = Shizuku.OnBinderReceivedListener { ui.post { refreshStatus() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        refreshStatus()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        super.onDestroy()
    }

    // ---------- UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun edit(hint: String, value: String, numeric: Boolean) = EditText(this).apply {
        this.hint = hint; setText(value); setSingleLine()
        if (numeric) inputType = InputType.TYPE_CLASS_NUMBER
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(40), dp(14), dp(24))
        }
        status = TextView(this).apply { textSize = 14f }
        root.addView(status)

        root.addView(button("1. Shizuku permission lo") {
            if (!Shell.binderAlive()) log("Shizuku chal nahi raha. Pehle Shizuku app kholo aur start karo.")
            else if (Shell.granted()) log("Permission pehle se mili hui hai.")
            else Shizuku.requestPermission(100)
        })

        val sizeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        etW = edit("W", "720", true); etH = edit("H", "1600", true); etDpi = edit("DPI", "320", true)
        listOf(etW, etH, etDpi).forEach {
            sizeRow.addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(sizeRow)

        root.addView(button("2. Virtual Display start karo") { startDisplay() })

        etPkg = edit("Package", "net.metaquotes.metatrader5", false)
        root.addView(etPkg)
        root.addView(button("3. App display par launch karo") { launchApp() })
        root.addView(button("4. Screenshot lo (display ki)") { screenshot() })
        root.addView(button("5. Check: display par kaun sa app chal raha?") { checkTop() })

        preview = ImageView(this).apply {
            setBackgroundColor(0xFFDDDDDD.toInt())
            scaleType = ImageView.ScaleType.FIT_XY
            setOnTouchListener { v, e -> if (e.action == MotionEvent.ACTION_UP) onPreviewTap(v, e); true }
        }
        root.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220)))
        root.addView(TextView(this).apply {
            text = "Upar screenshot par tap karo = display par asli tap jayega."
            textSize = 12f
        })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("Back") { sendKey(4) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(button("Force-stop app") { forceStop() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(button("Display stop") { stopDisplay() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row)

        logView = TextView(this).apply { textSize = 12f; setTextIsSelectable(true) }
        root.addView(logView)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun log(msg: String) {
        logView.text = "${logView.text}\n> $msg".takeLast(6000)
    }

    private fun refreshStatus() {
        val svc = VDService.instance
        status.text = "Shizuku: " + (if (!Shell.binderAlive()) "NOT RUNNING" else if (Shell.granted()) "READY" else "permission chahiye") +
                "\nDisplay: " + (if (svc != null && svc.displayId >= 0) "id=${svc.displayId} (${svc.width}x${svc.height}), frames=${svc.frames}" else "band")
    }

    private fun bg(block: () -> Unit) = Thread {
        block()
        ui.post { refreshStatus() }
    }.start()

    private fun needReady(): Boolean {
        if (!Shell.granted()) { log("Pehle step 1 (Shizuku) poora karo."); return false }
        return true
    }

    private fun needDisplay(): VDService? {
        val s = VDService.instance
        if (s == null || s.displayId < 0) { log("Pehle step 2: display start karo."); return null }
        return s
    }

    // ---------- actions ----------
    private fun startDisplay() {
        val w = etW.text.toString().toIntOrNull() ?: 720
        val h = etH.text.toString().toIntOrNull() ?: 1600
        val d = etDpi.text.toString().toIntOrNull() ?: 320
        val i = Intent(this, VDService::class.java).setAction(VDService.ACTION_START)
            .putExtra("w", w).putExtra("h", h).putExtra("dpi", d)
        startForegroundService(i)
        log("Display bana raha hoon ${w}x$h @${d}dpi ...")
        ui.postDelayed({
            val s = VDService.instance
            log(if (s != null && s.displayId >= 0) "OK: display id = ${s.displayId}" else "FAIL: display nahi bana.")
            refreshStatus()
        }, 900)
    }

    private fun launchApp() {
        if (!needReady()) return
        val s = needDisplay() ?: return
        val pkg = etPkg.text.toString().trim()
        bg {
            val chk = Shell.run("pm path $pkg")
            if (chk.second.isBlank()) {
                ui.post { log("Package '$pkg' installed nahi mila.") }
                return@bg
            }
            val r = Shell.run("am start --display ${s.displayId} -a android.intent.action.MAIN " +
                    "-c android.intent.category.LAUNCHER -p $pkg")
            ui.post { log("Launch (exit ${r.first}):\n${r.second.take(500)}") }
        }
    }

    private fun screenshot(thenToast: Boolean = false) {
        val s = needDisplay() ?: return
        bg {
            val bmp = s.snapshot()
            ui.post {
                if (bmp == null) {
                    log("Abhi tak koi frame nahi aaya. App launch karo ya thora intezar karo.")
                } else {
                    preview.setImageBitmap(bmp)
                    val lp = preview.layoutParams
                    lp.height = (preview.width.toFloat() * bmp.height / bmp.width).toInt().coerceAtLeast(dp(120))
                    preview.layoutParams = lp
                    val black = isAllBlack(bmp)
                    val f = save(bmp)
                    log("Screenshot ${bmp.width}x${bmp.height}, frames=${s.frames}" +
                            (if (black) "\n!!! Poori kaali frame: app display par render nahi hua (ya FLAG_SECURE)." else "\nFrame mein content hai.") +
                            "\nSaved: ${f?.name}")
                }
            }
        }
    }

    private fun isAllBlack(b: Bitmap): Boolean {
        var lit = 0
        val stepX = (b.width / 20).coerceAtLeast(1); val stepY = (b.height / 40).coerceAtLeast(1)
        var y = 0
        while (y < b.height) {
            var x = 0
            while (x < b.width) {
                val p = b.getPixel(x, y)
                if ((p and 0x00FFFFFF) != 0) lit++
                x += stepX
            }
            y += stepY
        }
        return lit == 0
    }

    private fun save(b: Bitmap): File? = try {
        val f = File(getExternalFilesDir(null), "shot_${System.currentTimeMillis()}.png")
        FileOutputStream(f).use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        f
    } catch (e: Throwable) { null }

    private fun onPreviewTap(v: View, e: MotionEvent) {
        if (!needReady()) return
        val s = needDisplay() ?: return
        val x = (e.x / v.width * s.width).toInt().coerceIn(0, s.width - 1)
        val y = (e.y / v.height * s.height).toInt().coerceIn(0, s.height - 1)
        bg {
            val r = Shell.run("input -d ${s.displayId} tap $x $y")
            ui.post {
                log("Tap ($x,$y) exit=${r.first} ${r.second.take(200)}")
                ui.postDelayed({ screenshot() }, 900)
            }
        }
    }

    private fun sendKey(code: Int) {
        if (!needReady()) return
        val s = needDisplay() ?: return
        bg {
            val r = Shell.run("input -d ${s.displayId} keyevent $code")
            ui.post { log("Key $code exit=${r.first} ${r.second.take(200)}"); ui.postDelayed({ screenshot() }, 700) }
        }
    }

    private fun checkTop() {
        if (!needReady()) return
        val s = needDisplay() ?: return
        bg {
            val r = Shell.run("dumpsys activity activities | grep -E 'Display #|ResumedActivity|mResumedActivity' | head -n 20")
            ui.post { log("Display id ${s.displayId} dhoondo is output mein:\n${r.second.take(1500)}") }
        }
    }

    private fun forceStop() {
        if (!needReady()) return
        val pkg = etPkg.text.toString().trim()
        bg {
            val r = Shell.run("am force-stop $pkg")
            ui.post { log("force-stop $pkg exit=${r.first}") }
        }
    }

    private fun stopDisplay() {
        startService(Intent(this, VDService::class.java).setAction(VDService.ACTION_STOP))
        log("Display stop kiya.")
        ui.postDelayed({ refreshStatus() }, 500)
    }
}
