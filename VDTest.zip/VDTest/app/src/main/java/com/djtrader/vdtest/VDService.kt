package com.djtrader.vdtest

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder

/**
 * Owns the virtual display. The display lives only while this service lives,
 * so it runs as a foreground service with a persistent notification.
 */
class VDService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        private const val CHANNEL = "vd_test"

        @Volatile var instance: VDService? = null
    }

    @Volatile var displayId: Int = -1
    @Volatile var width = 720
    @Volatile var height = 1600
    @Volatile var frames = 0L

    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var frameBmp: Bitmap? = null
    private val lock = Any()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                goForeground()
                val w = intent.getIntExtra("w", 720)
                val h = intent.getIntExtra("h", 1600)
                val d = intent.getIntExtra("dpi", 320)
                createDisplay(w, h, d)
            }
            ACTION_STOP -> shutdown()
        }
        return START_NOT_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "VD Test", NotificationManager.IMPORTANCE_LOW)
        )
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("VD Test chal raha hai")
            .setContentText("Virtual display active")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun createDisplay(w: Int, h: Int, dpi: Int) {
        releaseDisplay()
        width = w; height = h; frames = 0
        val t = HandlerThread("vd-frames").also { it.start() }
        thread = t
        val handler = Handler(t.looper)

        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Throwable) { null } ?: return@setOnImageAvailableListener
            try {
                val pl = img.planes[0]
                val rowPx = pl.rowStride / pl.pixelStride
                synchronized(lock) {
                    var b = frameBmp
                    if (b == null || b.width != rowPx || b.height != h) {
                        b = Bitmap.createBitmap(rowPx, h, Bitmap.Config.ARGB_8888)
                        frameBmp = b
                    }
                    pl.buffer.rewind()
                    b.copyPixelsFromBuffer(pl.buffer)
                    frames++
                }
            } catch (_: Throwable) {
            } finally {
                img.close()
            }
        }, handler)
        reader = r

        val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        // bit 6 = SUPPORTS_TOUCH, bit 8 = DESTROY_CONTENT_ON_REMOVAL (hidden constants)
        val flags = DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC or
                DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY or
                (1 shl 6) or (1 shl 8)
        val v = dm.createVirtualDisplay("DJ896-VD", w, h, dpi, r.surface, flags, null, null)
        vd = v
        displayId = v?.display?.displayId ?: -1
        instance = this
    }

    /** Latest rendered frame as a fresh bitmap, or null if nothing was drawn yet. */
    fun snapshot(): Bitmap? = synchronized(lock) {
        val f = frameBmp ?: return null
        val c = Bitmap.createBitmap(f, 0, 0, width, height)
        if (c === f) f.copy(Bitmap.Config.ARGB_8888, false) else c
    }

    private fun releaseDisplay() {
        try { vd?.release() } catch (_: Throwable) {}
        try { reader?.close() } catch (_: Throwable) {}
        thread?.quitSafely()
        vd = null; reader = null; thread = null
        synchronized(lock) { frameBmp = null }
        displayId = -1
    }

    private fun shutdown() {
        releaseDisplay()
        instance = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        releaseDisplay()
        instance = null
        super.onDestroy()
    }
}
