package com.djtrader.vdtest

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Runs shell commands with shell-level (ADB) rights through Shizuku. */
object Shell {

    fun binderAlive(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    /** Returns (exitCode, combined stdout+stderr). Call from a background thread. */
    fun run(cmd: String): Pair<Int, String> {
        return try {
            // Shizuku.newProcess is private in API 13+, so call it by reflection.
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", "$cmd 2>&1"), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            code to out.trim()
        } catch (e: Throwable) {
            -1 to "Shell error: ${e.cause?.message ?: e.message}"
        }
    }
}
