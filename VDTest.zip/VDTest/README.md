# VD Test (DJ 896) - Virtual Display feasibility test

Maqsad: sirf yeh check karna ke aapke phone par
1. MT5 virtual display par khulta hai?
2. Us display ki screen padhi ja sakti hai?
3. Us par tap lagta hai?

## Build
1. Android Studio mein `VDTest` folder open karo, Gradle sync hone do.
2. Phone par Developer options > USB debugging (ya Wireless debugging) on karo.
3. Run karo, ya Build > Build APK.

## Shizuku setup (ek baar)
1. Play Store se **Shizuku** install karo.
2. Android 11+: Developer options > Wireless debugging on, phir Shizuku mein "Pairing" aur "Start" karo (guide Shizuku app mein hai).
3. Har reboot ke baad Shizuku dobara start karna padta hai.

## Test order
1. Step 1: Shizuku permission do.
2. Step 2: Virtual Display start (720x1600, 320dpi theek hai).
3. Step 3: MT5 launch (package `net.metaquotes.metatrader5`).
4. Step 4: Screenshot. Preview mein MT5 dikhna chahiye. Phone ki asli screen par MT5 nahi aana chahiye.
5. Preview par tap karo: tap display par jata hai, 1 second baad screenshot khud refresh hota hai.
6. Step 5 se confirm karo ke MT5 sahi display id par chal raha hai.

## Natija kaise padhein
- Screenshot mein MT5 dikha + tap chala  = Virtual Display route mumkin hai, aage ka kaam shuru kar sakte hain.
- Screenshot poora kaala = MT5 us display par render nahi hua ya FLAG_SECURE hai.
- MT5 asli screen par khul gaya = phone ROM virtual display par launch allow nahi karta.
- "Display nahi bana" = ROM ne public virtual display block kiya.
- Screen lock karke phir test karo: yahi asli background test hai.

Sirf DEMO account par test karo. Is test app mein koi trading ya AI logic nahi hai.
